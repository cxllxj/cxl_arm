/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created: Sat Jul 11 16:37:57 2015
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLineEdit *m_x;
    QLineEdit *m_y;
    QLineEdit *m_result;
    QLabel *label;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(240, 240);
        pushButton = new QPushButton(Widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(130, 40, 21, 26));
        pushButton_2 = new QPushButton(Widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(70, 190, 80, 26));
        m_x = new QLineEdit(Widget);
        m_x->setObjectName(QString::fromUtf8("m_x"));
        m_x->setGeometry(QRect(10, 40, 51, 25));
        m_y = new QLineEdit(Widget);
        m_y->setObjectName(QString::fromUtf8("m_y"));
        m_y->setGeometry(QRect(80, 40, 41, 25));
        m_result = new QLineEdit(Widget);
        m_result->setObjectName(QString::fromUtf8("m_result"));
        m_result->setGeometry(QRect(160, 40, 51, 25));
        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 40, 21, 20));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "My Calc", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("Widget", "=", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("Widget", "close", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Widget", "+", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
