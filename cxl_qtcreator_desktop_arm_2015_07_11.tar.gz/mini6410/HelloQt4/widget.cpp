#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_clicked()
{
        ui->m_result->setText( "" );
        if (ui->m_x->text().isEmpty() || ui->m_y->text().isEmpty()) {
           return ;
        }

        bool ok = false;
        int x = ui->m_x->text().toInt(&ok);
        if (!ok) {
           ui->m_x->setText("");
           return ;
        }

        ok = false;
        int y = ui->m_y->text().toInt(&ok);
        if (!ok) {
           ui->m_y->setText("");
           return ;
        }

        ui->m_result->setText( QString::number( x + y ) );
}

void Widget::on_pushButton_2_clicked()
{
    close();
}
