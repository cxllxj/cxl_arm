#include <QApplication>
#include <QLabel>

int main(int argc,char *argv[])
{
	QApplication a(argc,argv);
	QLabel label("Hello mini6410!");
 	label.show();
	return a.exec();
}
