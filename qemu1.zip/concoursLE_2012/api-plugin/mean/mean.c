#include <stdlib.h>

#include "plugin.h"

#ifdef __cplusplus
extern "C" {
#endif

struct limit_level_ctx {
	int sum;
	int nb_value;
};

static t_plugin_private* init(void);
static void reset(t_plugin_private *plugin_ctx,
                  struct plugin_signal_settings *settings);
static void destroy(t_plugin_private *plugin_ctx);
static int process(t_plugin_private *plugin_ctx,
                   const struct plugin_signal *in_signals,
                   int *res_int);

static struct plugin_ops_v1 plugin_ops =
	{
		.help = "Compute the mean of a signal",

		.init = init,
		.reset = reset,
		.destroy = destroy,

		.type = PLUGIN_RET_INT,
		.nb_args = 1,
		.label = "Mean",
		.unit = "V",
		.process.ret_int = process,
	};

struct plugin plugin =
	{
		.version = PLUGIN_API_VERSION,
		.name = "mean",
		.author = "Albin Kauffmann <albin.kauffmann@openwide.fr>",

		.plugin_ops.v1 = &plugin_ops,
	};

static t_plugin_private* init(void)
{
	struct limit_level_ctx *ctx = malloc(sizeof (struct limit_level_ctx));

	return (t_plugin_private *) ctx;
}

static void reset(t_plugin_private *plugin_ctx,
                  struct plugin_signal_settings *settings)
{
	struct limit_level_ctx *ctx = (struct limit_level_ctx *) plugin_ctx;

	ctx->sum = 0;
	ctx->nb_value = 0;
}

static void destroy(t_plugin_private *plugin_ctx)
{
	struct limit_level_ctx *ctx = (struct limit_level_ctx *) plugin_ctx;

	free(ctx);
}

static int process(t_plugin_private *plugin_ctx,
                   const struct plugin_signal *in_signals,
                   int *res_int)
{
	struct limit_level_ctx *ctx = (struct limit_level_ctx *) plugin_ctx;
	unsigned int i;

	for (i = in_signals[0].start; i < in_signals[0].end; ++i)
		ctx->sum += in_signals[0].volts[i];
	ctx->nb_value += in_signals[0].end - in_signals[0].start;

	*res_int = ctx->sum / ctx->nb_value;

	return 0;
}

#ifdef __cplusplus
}
#endif
