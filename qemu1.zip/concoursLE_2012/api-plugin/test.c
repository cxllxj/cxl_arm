#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>

#include "plugin.h"

int main(int argc, char *argv[])
{
	void *handle;
	struct plugin *plugin;

	if (argc != 2)
	{
		puts("usage: ./test [PLUGIN]");
		return EXIT_FAILURE;
	}

	printf("Openning plugin %s\n", argv[1]);

	if ((handle = dlopen(argv[1], RTLD_LAZY)) == NULL)
	{
		fprintf(stderr, "%s\n", dlerror());
		return EXIT_FAILURE;
	}

	if ((plugin = dlsym(handle, "plugin")) == NULL)
	{
		fprintf(stderr, "%s\n", dlerror());
		dlclose(handle);
		return EXIT_FAILURE;
	}

	printf("name = %s\nauthor = %s\nversion = %d.%d\n", plugin->name, plugin->author,
	       plugin->version >> 8, plugin->version & 0xFF);

	dlclose(handle);

	return EXIT_SUCCESS;
}
