#include <stdlib.h>

#include "plugin.h"

#define LEVEL_VOLT 0.5

#ifdef __cplusplus
extern "C" {
#endif

struct limit_level_ctx {
	uint16_t max;
};

static t_plugin_private* init(void);
static void reset(t_plugin_private *plugin_ctx,
                  struct plugin_signal_settings *settings);
static void destroy(t_plugin_private *plugin_ctx);
static int process(t_plugin_private *plugin_ctx,
                   const struct plugin_signal *in_signals,
                   struct plugin_signal *res_signal);

static struct plugin_ops_v1 plugin_ops =
	{
		.help = "Limit the signal to 0.5V",

		.init = init,
		.reset = reset,
		.destroy = destroy,

		.type = PLUGIN_RET_SIGNAL,
		.nb_args = 1,
		.label = "Limit to 0.5V",
		.unit = "V",
		.process.ret_signal = process,
	};

struct plugin plugin =
	{
		.version = PLUGIN_API_VERSION,
		.name = "limit_level",
		.author = "yargil & albinou",

		.plugin_ops.v1 = &plugin_ops,
	};

static t_plugin_private* init(void)
{
	struct limit_level_ctx *ctx = malloc(sizeof (struct limit_level_ctx));

	return (t_plugin_private *) ctx;
}

static void reset(t_plugin_private *plugin_ctx,
                  struct plugin_signal_settings *settings)
{
	struct limit_level_ctx *ctx = (struct limit_level_ctx *) plugin_ctx;

	ctx->max = LEVEL_VOLT * (1 << settings->bits_per_sample) /
		settings->max_voltage;
}

static void destroy(t_plugin_private *plugin_ctx)
{
	struct limit_level_ctx *ctx = (struct limit_level_ctx *) plugin_ctx;

	free(ctx);
}

static int process(t_plugin_private *plugin_ctx,
                   const struct plugin_signal *in_signals,
                   struct plugin_signal *res_signal)
{
	struct limit_level_ctx *ctx = (struct limit_level_ctx *) plugin_ctx;
	unsigned int i;

	for (i = in_signals[0].start; i < in_signals[0].end; ++i)
		res_signal->volts[i] = (in_signals[0].volts[i] < ctx->max) ?
			in_signals[0].volts[i] : ctx->max;

	return 0;
}

#ifdef __cplusplus
}
#endif
