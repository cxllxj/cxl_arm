#include <stdlib.h>

#include "plugin.h"

#ifdef __cplusplus
extern "C" {
#endif

static t_plugin_private* init(void);
static void reset(t_plugin_private *plugin_ctx,
                  struct plugin_signal_settings *settings);
static void destroy(t_plugin_private *plugin_ctx);
static int process(t_plugin_private *plugin_ctx,
                   const struct plugin_signal *in_signals,
                   struct plugin_signal *res_signal);

static struct plugin_ops_v1 plugin_ops =
	{
		.help = "Computes the sum of 2 signals",

		.init = init,
		.reset = reset,
		.destroy = destroy,

		.type = PLUGIN_RET_SIGNAL,
		.nb_args = 2,
		.label = "Sum",
		.unit = "V",
		.process.ret_signal = process,
	};

struct plugin plugin =
	{
		.version = PLUGIN_API_VERSION,
		.name = "sum",
		.author = "Albin Kauffmann <albin.kauffmann@openwide.fr>",

		.plugin_ops.v1 = &plugin_ops,
	};

static t_plugin_private* init(void)
{
	return NULL;
}

static void reset(t_plugin_private *plugin_ctx,
                  struct plugin_signal_settings *settings)
{
}

static void destroy(t_plugin_private *plugin_ctx)
{
}

static int process(t_plugin_private *plugin_ctx,
                   const struct plugin_signal *in_signals,
                   struct plugin_signal *res_signal)
{
	unsigned int i;

	if ((in_signals[0].start != in_signals[1].start) ||
	    (in_signals[0].end != in_signals[1].end))
		return -1;

	for (i = in_signals[0].start; i < in_signals[0].end; ++i)
		res_signal->volts[i] = in_signals[0].volts[i] + in_signals[1].volts[i];

	return 0;
}

#ifdef __cplusplus
}
#endif
