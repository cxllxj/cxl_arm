# 0 - QEMU : les commandes et les commentaires pour Qemu

# 1 - build.sh : le script �� ex��cuter si vous voulez g��n��rer l'image finale depuis "Z��ro" et d��marrer Qemu avec l'image finale "nand.bin"

# 2 - direct_test/direct_test.sh : le script �� ex��cuter si vous voulez directement tester l'image finale jointe (sans la compilation et la g��n��ration, se trouve dans le r��pertoire images)

# 3 - .config : le fichier de configuration pour Buildroot

# 4 - lua : r��pertoire contenant le patch pour l'erreur de lua-host-5.1.4 pendant la compilation de Buildroot

# 5 - phase1.pdf et phase1.odt : les deux documents contenant les m��mes contenus qui d��crivent le travail

# 6 - cle2012 : r��pertoire contenant les codes sources

# 7 - lib : r��pertoire contenant les fichiers .so

# 8 - api-plugin : r��pertoire contenant les codes source des plugin

# 9 - nand.bin : image finale jointe pour direct_test

# 10 - images : r��pertoire contenant mon application pr��compil��e "cle2012" pour direct_test

# 11 - flashimg : r��pertoire contenant les codes sources de l'outil "flashimg" d��velopp�� par Yargil

# 12 - TODO : tests et exp��rimentations pr��vus sur le mat��riel r��el �� faire pour la 2i��me Phase si pourvoir r��ussir la 1��re

# 13 - COPYING : licence GPL
