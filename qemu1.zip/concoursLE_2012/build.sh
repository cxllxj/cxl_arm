#!/bin/bash

# If there occurs an error, exit the whole script
set -e

base=$PWD

echo "################## BUILDING L'OUTIL FLASHIMG ##################"
cd flashimg
./autogen.sh
./configure
make
sudo make install
echo "Done FLASHIMG ......"

echo "################## GETTING QEMU ##################"
cd $base
git clone git://repo.or.cz/qemu/mini2440.git qemu
mkdir local
cd qemu
./configure --target-list=arm-softmmu --prefix=$base/local
make
make install
echo "Done QEMU ......"

export PATH=$base/local/bin:$PATH

echo "################## GETTING BUILDROOT AND BUILDING ##################"
cd $base
wget http://buildroot.org/downloads/buildroot-2012.05.tar.gz
tar zxvf buildroot-2012.05.tar.gz
cd buildroot-2012.05

# Utiliser le fichier de configuration deja modifie ".config"
cp $base/.config ./.config

# Implementer le the patch pour lua-host-5.1.4
cp $base/lua/host-lua.patch ./package/lua/host-lua.patch
cd ./package/lua
patch -p1 < host-lua.patch

# Compiler Buildroot
cd $base/buildroot-2012.05
make

# Compiler mon application Qt avec le qmake venant etre genere par Buildroot
cd $base/cle2012
../buildroot-2012.05/output/host/usr/bin/qmake -project
../buildroot-2012.05/output/host/usr/bin/qmake cle2012.pro
make

# Ajouter mon application dans bin du filesystem genere par Buildroot
cd $base/buildroot-2012.05
cp $base/cle2012/cle2012 ./output/target/bin/cle2012

# Ajouter les trois .so fichiers dans lib du filesystem genere par Buildroot
cp $base/lib/limit_level.so ./output/target/lib/limit_level.so
cp $base/lib/mean.so ./output/target/lib/mean.so
cp $base/lib/sum.so ./output/target/lib/sum.so

# Rectrompiler pour juste regenerer le fichier "rootfs.jffs2"
make
echo "Done BUILDROOT ......"

echo "################## MAKING IMAGE (NAND.BIN) ##################"
cp ./output/images/rootfs.jffs2 $base/flashimg/rootfs.jffs2
cp ./output/images/uImage $base/flashimg/uImage
cp ./output/images/u-boot.bin $base/flashimg/u-boot.bin
cd $base/flashimg
./flashimg -s 64M -t nand -f nand.bin -p uboot.part -w boot,u-boot.bin -w kernel,uImage -w root,rootfs.jffs2 -z 512
echo "Done NAND.BIN ......"

echo "################## STARTING QEMU ##################"
qemu-system-arm -M mini2440 -serial stdio -mtdblock nand.bin -usbdevice mouse

#### Les commandes suivantes doivent etre executees dans Qemu
#   MINI2440 # nboot kernel
#   MINI2440 # setenv bootargs root=/dev/mtdblock3 rootfstype=jffs2 console=ttySAC0,115200 mini2440=3tb
#   MINI2440 # saveenv
#   MINI2440 # bootm
#### Le mot de passe pour buildroot login est: root
#   Welcome to Buildroot
#   buildroot login: root

#   # cle2012 -qws

### Les fichiers sauvegardes (chan1.pcm, chan2.pcm et cle.cfg) sont dans /home/default/
