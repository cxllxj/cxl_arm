#ifndef MYWINDOW_H
#define MYWINDOW_H

#include <QMainWindow>
#include <QtGui>
#include "ui_mywindow.h"

namespace Ui {
    class myWindow;
}

class myWindow : public QMainWindow, public Ui::myWindow
{
    Q_OBJECT
    
public:
    myWindow(QWidget *parent = 0);
    ~myWindow();

    void init();
    void paintEvent(QPaintEvent*);
    void setBack(QPainter* painter);

    // The function to generate the X-axis coordinate for all the curves
    void generate_x();

    // channel 1
    void display_chan1_trig(QPainter* painter);
    void display_chan1_sina(QPainter* painter);
    void display_chan1_rect(QPainter* painter);
    void display_chan1_sawt(QPainter* painter);

    //channel 2
    void display_chan2_trig(QPainter* painter);
    void display_chan2_sina(QPainter* painter);
    void display_chan2_rect(QPainter* painter);
    void display_chan2_sawt(QPainter* painter);

    void display_sum(QPainter* painter);

public slots:
    void draw(QPainter* painter);

    // channel 1
    void draw_chan1_trig(QPainter* painter);  // triangulaire
    void draw_chan1_sina(QPainter* painter);  // sinusoïdale
    void draw_chan1_rect(QPainter* painter);  // rectangle
    void draw_chan1_sawt(QPainter* painter);  // sawtooth

    void set_chan1_trig();
    void set_chan1_sina();
    void set_chan1_rect();
    void set_chan1_sawt();

    // channel 2
    void draw_chan2_trig(QPainter* painter);  // triangulaire
    void draw_chan2_sina(QPainter* painter);  // sinusoïdale
    void draw_chan2_rect(QPainter* painter);  // rectangle
    void draw_chan2_sawt(QPainter* painter);  // sawtooth

    void set_chan2_trig();
    void set_chan2_sina();
    void set_chan2_rect();
    void set_chan2_sawt();

    void draw_sum(QPainter* painter);
    void set_sum();

    void draw_infor(QPainter* painter);

    void mean(QPainter* painter);

    void raise_trigger();
    void lower_trigger();

    void slower_timebase();
    void faster_timebase();
    void raise_tension();
    void lower_tension();

    void refresh();

    void openFile();
    void saveFiles();
    
private:
    Ui::myWindow *ui;

    // channel 1
    QVector<QPointF> point_chan1_trig;
    QVector<QPointF> point_chan1_sina;
    QVector<QPointF> point_chan1_rect;
    QVector<QPointF> point_chan1_sawt;

    // channel 2
    QVector<QPointF> point_chan2_trig;
    QVector<QPointF> point_chan2_sina;
    QVector<QPointF> point_chan2_rect;
    QVector<QPointF> point_chan2_sawt;

    QVector<QPointF> point_sum;

    QVector<QPointF> point_for_trigger;

    QVector<qreal> x_coor;  // X-axis coordinates for all the curves

    qreal t_time;
    qreal a_tension;

    qreal time_base;     // ms/div
    qreal tension_div;  // V/div

    qreal mean_chan1;
    qreal mean_chan2;

    qreal limit_volt;

    qreal trigger_volt;

    QMessageBox *megBox;

    QActionGroup *chan1_group;
    QActionGroup *chan2_group;
    QActionGroup *trigger_group;
};

#endif // MYWINDOW_H
