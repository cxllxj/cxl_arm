#include "mywindow.h"
#include "ui_mywindow.h"

/* Global variable */

qreal EMPTY = 10000;               // EMPTY means there is no point in the vector
qreal INITIAL_TRIGGER_VOLT = 0.8;  // initial triggering voltage
qreal INITIAL_MAX_VOLT = 3.3;      // initial max voltage
int INITIAL_SAMPLE_RATE = 22050;   // initial sampling rate
int middle_1 = 131;                // middle coordinate of Y for channel 1
//int middle_2 = 111;                // middle coordinate of Y for channel 2
int samp_num = 60;         // sampling number per period

QString savePath("/home/oscar/test_for_files_cle2012/");
//QString savePath("/home/default/");

/* Constructor */

myWindow::myWindow(QWidget *parent) : QMainWindow(parent)
{
    setupUi(this);
    init();
}

/* QPaintEvent */

void myWindow::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    setBack(&p);
    draw(&p);
}

/* Set the drawing board back */

void myWindow::setBack(QPainter* painter)
{
    painter->fillRect(0, 23, 320, 240, Qt::black); // Background

    QPen pen(Qt::blue, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    painter->setPen(pen);
    painter->drawLine(10, 31, 310, 31);  // Upper-Frame
    painter->drawLine(10, 231, 310, 231);   // Lower-Frame
    painter->drawLine(310, 31, 310, 231);  // Right-Frame
    painter->drawLine(10, 31, 10, 231);  // Left-Frame

    QPen pen1(Qt::blue, 1, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    painter->setPen(pen1);
    painter->drawLine(160, 31, 160, 231);  // Y-axis
    painter->drawLine(10, 131, 310, 131);   // X-axis

    QPen pen2(Qt::blue, 1, Qt::DotLine, Qt::RoundCap, Qt::RoundJoin);
    painter->setPen(pen2);
    /* DotLine of Horizontal direction */
    painter->drawLine(10, 51, 310, 51);
    painter->drawLine(10, 71, 310, 71);
    painter->drawLine(10, 91, 310, 91);
    painter->drawLine(10, 111, 310, 111);
    painter->drawLine(10, 151, 310, 151);
    painter->drawLine(10, 171, 310, 171);
    painter->drawLine(10, 191, 310, 191);
    painter->drawLine(10, 211, 310, 211);
    /* DotLine of Vertical direction */
    painter->drawLine(40, 31, 40, 231);
    painter->drawLine(70, 31, 70, 231);
    painter->drawLine(100, 31, 100, 231);
    painter->drawLine(130, 31, 130, 231);
    painter->drawLine(190, 31, 190, 231);
    painter->drawLine(220, 31, 220, 231);
    painter->drawLine(250, 31, 250, 231);
    painter->drawLine(280, 31, 280, 231);

//    QPen pen3(Qt::blue);
//    painter->setPen(pen3);
//    QFont font("Arial", 20, QFont::DemiBold, false);
//    painter->setFont(font);
//    /* Draw the numbers of tension en Volt */
//    painter->drawText(141, 38, tr("5.0"));
//    painter->drawText(141, 50, tr("4.0"));
//    painter->drawText(141, 70, tr("3.0"));
//    painter->drawText(141, 90, tr("2.0"));
//    painter->drawText(141, 110, tr("1.0"));
//    painter->drawText(152, 130, tr("0"));
//    painter->drawText(137, 150, tr("-1.0"));
//    painter->drawText(137, 170, tr("-2.0"));
//    painter->drawText(137, 190, tr("-3.0"));
//    painter->drawText(137, 210, tr("-4.0"));
//    painter->drawText(137, 230, tr("-5.0"));
}

void myWindow::init()
{
    // set the seed of qrand, white Gaussian noise, WGN
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

    // Initialise the limit_volt
    limit_volt = INITIAL_MAX_VOLT;

    // Initialise the triggering voltage
    trigger_volt = INITIAL_TRIGGER_VOLT;

    t_time = 30;        // 3 ms
    a_tension = 10;     // 0.5 V

    time_base = 30;
    tension_div = 10;

    /* Add the four QActions for channel in each corresponding QActionGroup */
    chan1_group = new QActionGroup(this);
    chan1_group->addAction(action_chan1_trig);
    chan1_group->addAction(action_chan1_sina);
    chan1_group->addAction(action_chan1_rect);
    chan1_group->addAction(action_chan1_sawt);

    chan2_group = new QActionGroup(this);
    chan2_group->addAction(action_chan2_trig);
    chan2_group->addAction(action_chan2_sina);
    chan2_group->addAction(action_chan2_rect);
    chan2_group->addAction(action_chan2_sawt);

    /* Add the three options of triggering in the QActionGroup */
    trigger_group = new QActionGroup(this);
    trigger_group->addAction(trigger_off);
    trigger_group->addAction(trigger_rising);
    trigger_group->addAction(trigger_falling);

    // generate the X-axis coordinates for all the curves
    generate_x();

    // channel 1 trig signals
    connect(action_chan1_trig, SIGNAL(changed()), this, SLOT(update()));

    // channel 1 sina signals
    connect(action_chan1_sina, SIGNAL(changed()), this, SLOT(update()));

    // channel 1 rect signals
    connect(action_chan1_rect, SIGNAL(changed()), this, SLOT(update()));

    // channel 1 sawt signals
    connect(action_chan1_sawt, SIGNAL(changed()), this, SLOT(update()));

    // channel 2 trig signals
    connect(action_chan2_trig, SIGNAL(changed()), this, SLOT(update()));

    // channel 2 sina signals
    connect(action_chan2_sina, SIGNAL(changed()), this, SLOT(update()));

    // channel 2 rect signals
    connect(action_chan2_rect, SIGNAL(changed()), this, SLOT(update()));

    // channel 2 sawt signals
    connect(action_chan2_sawt, SIGNAL(changed()), this, SLOT(update()));

    // Plugin sum
    connect(Sum_2, SIGNAL(changed()), this, SLOT(update()));

    // Plugin mean
    connect(Mean, SIGNAL(changed()), this, SLOT(update()));

    // Plugin limit
    connect(Limit, SIGNAL(changed()), this, SLOT(update()));

    // Open a file chan1.pcm, chan2.pcm or cle.cfg
    connect(Open, SIGNAL(activated()), this, SLOT(openFile()));

    // Save the data to chan1.pcm, chan2.pcm and the file cle.cfg
    connect(Save, SIGNAL(activated()), this, SLOT(saveFiles()));

    // Quit the application
    connect(Quit, SIGNAL(activated()), this, SLOT(close()));

    // Trigger voltage changing
    connect(action_raise_trigger, SIGNAL(activated()), this, SLOT(raise_trigger()));
    connect(action_lower_trigger, SIGNAL(activated()), this, SLOT(lower_trigger()));

    // Slower the Time Base   (ms/div)
    connect(slower_time_base, SIGNAL(activated()), this, SLOT(slower_timebase()));

    // Faster the Time Base   (ms/div)
    connect(faster_time_base, SIGNAL(activated()), this, SLOT(faster_timebase()));

    // Raise the Tension/div  (V/div)
    connect(raise_tension_div, SIGNAL(activated()), this, SLOT(raise_tension()));

    // Slower the Tension/div (V/div)
    connect(lower_tension_div, SIGNAL(activated()), this, SLOT(lower_tension()));

    // Refresh the screen, uncheck the 8 curves
    connect(Refresh, SIGNAL(activated()), this, SLOT(refresh()));

}

// Generate the X-axis coordinates for the 8 curves

void myWindow::generate_x()
{
    x_coor.clear();
    qreal x = 10;
    x_coor.append(x);
    for (int i=0; i < (qreal)samp_num * 300 / ((qreal)t_time * t_time / time_base); i++)
    {
        x += (qreal)t_time * t_time / samp_num / time_base;
        x_coor.append(x);
    }
}

// Draw channel 1 trig

void myWindow::draw_chan1_trig(QPainter* painter)
{
    painter->setPen(Qt::yellow);
    display_chan1_trig(painter);
}

// Draw channel 1 sina

void myWindow::draw_chan1_sina(QPainter* painter)
{
    painter->setPen(Qt::yellow);
    display_chan1_sina(painter);
}

// Draw channel 1 rect

void myWindow::draw_chan1_rect(QPainter* painter)
{
    painter->setPen(Qt::yellow);
    display_chan1_rect(painter);
}

// Draw channel 1 sawt

void myWindow::draw_chan1_sawt(QPainter* painter)
{
    painter->setPen(Qt::yellow);
    display_chan1_sawt(painter);
}

// Draw channel 2 trig

void myWindow::draw_chan2_trig(QPainter* painter)
{
    painter->setPen(Qt::green);
    display_chan2_trig(painter);
}

// Draw channel 2 sina

void myWindow::draw_chan2_sina(QPainter* painter)
{
    painter->setPen(Qt::green);
    display_chan2_sina(painter);
}

// Draw channel 2 rect

void myWindow::draw_chan2_rect(QPainter* painter)
{
    painter->setPen(Qt::green);
    display_chan2_rect(painter);
}

// Draw channel 2 sawt

void myWindow::draw_chan2_sawt(QPainter* painter)
{
    painter->setPen(Qt::green);
    display_chan2_sawt(painter);
}

/* All action draw */

void myWindow::draw(QPainter* painter)
{
    if (action_chan1_trig->isChecked()) {
        draw_chan1_trig(painter);
    }
    else if (action_chan1_sina->isChecked()) {
        draw_chan1_sina(painter);
    }
    else if (action_chan1_rect->isChecked()) {
        draw_chan1_rect(painter);
    }
    else if (action_chan1_sawt->isChecked()) {
        draw_chan1_sawt(painter);
    }

    if (action_chan2_trig->isChecked()) {
        draw_chan2_trig(painter);
    }
    else if (action_chan2_sina->isChecked()) {
        draw_chan2_sina(painter);
    }
    else if (action_chan2_rect->isChecked()) {
        draw_chan2_rect(painter);
    }
    else if (action_chan2_sawt->isChecked()) {
        draw_chan2_sawt(painter);
    }

    if (Sum_2->isChecked())
    {
        draw_sum(painter);
    }

    if (Mean->isChecked())
    {
        mean(painter);
    }

    if (Limit->isChecked())
    {
        limit_volt = 0.5;
        update();
    }
    else
    {
        limit_volt = INITIAL_MAX_VOLT;
        update();
    }

    draw_infor(painter);

    painter->fillRect(310, 31, 320, 231, Qt::black);
}

/* Display the trig, sina, rect and sawt for channel 1 */

void myWindow::display_chan1_trig(QPainter* painter)
{
    point_chan1_trig.clear();
    set_chan1_trig();
    painter->drawPoints(point_chan1_trig);
}

void myWindow::display_chan1_sina(QPainter* painter)
{
    point_chan1_sina.clear();
    set_chan1_sina();
    painter->drawPoints(point_chan1_sina);
}

void myWindow::display_chan1_rect(QPainter* painter)
{
    point_chan1_rect.clear();
    set_chan1_rect();
    painter->drawPoints(point_chan1_rect);
}

void myWindow::display_chan1_sawt(QPainter* painter)
{
    point_chan1_sawt.clear();
    set_chan1_sawt();
    painter->drawPoints(point_chan1_sawt);
}

/* Display the trig, sina, rect and sawt for channel 2 */

void myWindow::display_chan2_trig(QPainter* painter)
{
    point_chan2_trig.clear();
    set_chan2_trig();
    painter->drawPoints(point_chan2_trig);
}

void myWindow::display_chan2_sina(QPainter* painter)
{
    point_chan2_sina.clear();
    set_chan2_sina();
    painter->drawPoints(point_chan2_sina);
}

void myWindow::display_chan2_rect(QPainter* painter)
{
    point_chan2_rect.clear();
    set_chan2_rect();
    painter->drawPoints(point_chan2_rect);
}

void myWindow::display_chan2_sawt(QPainter* painter)
{
    point_chan2_sawt.clear();
    set_chan2_sawt();
    painter->drawPoints(point_chan2_sawt);
}

// Set channel 1 trig x,y

void myWindow::set_chan1_trig()
{
    QPointF p;
    qreal x, y, m;
    int j = 0;

    for (int i=0; i < x_coor.count(); i++)
    {
        j = 0;
        while (j < x_coor.count() / samp_num)
        {
            if (10 + (qreal)j * t_time * t_time / time_base <= x_coor[i] && x_coor[i] <= 10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base / 4)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base) / ((qreal)t_time * t_time / time_base / 4);
                x = x_coor[i];
                y = middle_1 - a_tension * (qreal)a_tension / tension_div
                        - a_tension * (qreal)a_tension / tension_div * m;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (qreal)a_tension / tension_div;

                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan1_trig.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan1_trig.append(p);
                }
            }
            else if (10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base / 4 <= x_coor[i] && x_coor[i] <= 10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base / 2)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base - (qreal)t_time * t_time / time_base / 4) / ((qreal)t_time * t_time / time_base / 4);
                x = x_coor[i];
                y = middle_1 - 2 * a_tension * (a_tension / tension_div)
                        + a_tension * (qreal)a_tension / tension_div * m;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (a_tension / tension_div);
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan1_trig.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan1_trig.append(p);
                }
            }
            else if (10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base / 2 <= x_coor[i] && x_coor[i] <= 10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base * 3 / 4)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base - (qreal)t_time * t_time / time_base / 2) / ((qreal)t_time * t_time / time_base / 4);
                x = x_coor[i];
                y = middle_1 - a_tension * (a_tension / tension_div)
                        + a_tension * (qreal)a_tension / tension_div * m;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (a_tension / tension_div);
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan1_trig.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan1_trig.append(p);
                }
            }
            else if (10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base * 3 / 4 <= x_coor[i] && x_coor[i] <= 10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base - (qreal)t_time * t_time / time_base * 3 / 4) / ((qreal)t_time * t_time / time_base / 4);
                x = x_coor[i];
                y = middle_1
                        - a_tension * (qreal)a_tension / tension_div * m;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (a_tension / tension_div);
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan1_trig.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan1_trig.append(p);
                }
            }
            j++;
        }
    }

    if (trigger_rising->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan1_trig.count(); i++)
        {
            p1 = point_chan1_trig[i];
            point_for_trigger.append(p1);
        }
        point_chan1_trig.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() < point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan1_trig.append(p1);
            }
        }
    }
    else if (trigger_falling->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan1_trig.count(); i++)
        {
            p1 = point_chan1_trig[i];
            point_for_trigger.append(p1);
        }
        point_chan1_trig.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() > point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan1_trig.append(p1);
            }
        }
    }
    else if (trigger_off->isChecked())
    {

    }
}

// Set channel 1 sina x,y

void myWindow::set_chan1_sina()
{
    QPointF p;
    qreal x, y, a;
    qreal TWOPI = 6.28318;
    int j;

    for (int i=0; i < x_coor.count(); i++)
    {
        j = 0;
        while (j < x_coor.count() / samp_num)
        {
            if (10 + (qreal)j * t_time * t_time / time_base <= x_coor[i] && x_coor[i] <= 10 + (qreal)(j+1) * t_time * t_time / time_base)
            {
                x = x_coor[i];
                a = TWOPI * (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base) / (t_time * t_time / time_base);
                y = middle_1 - (qreal)a_tension * a_tension / tension_div
                        - (qreal)a_tension * a_tension / tension_div * sin(a);
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (a_tension / tension_div);
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan1_sina.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan1_sina.append(p);
                }
            }
            j++;
        }
    }

    if (trigger_rising->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan1_sina.count(); i++)
        {
            p1 = point_chan1_sina[i];
            point_for_trigger.append(p1);
        }
        point_chan1_sina.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() < point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan1_sina.append(p1);
            }
        }
    }
    else if (trigger_falling->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan1_sina.count(); i++)
        {
            p1 = point_chan1_sina[i];
            point_for_trigger.append(p1);
        }
        point_chan1_sina.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() > point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan1_sina.append(p1);
            }
        }
    }
    else if (trigger_off->isChecked())
    {

    }
}

// Set channel 1 rect x,y

void myWindow::set_chan1_rect()
{
    QPointF p;
    qreal x, y;
    int j;

    for (int i=0; i < x_coor.count(); i++)
    {
        j = 0;
        while (j < x_coor.count() / samp_num)
        {
            if (10 + (qreal)j * t_time * t_time / time_base <= x_coor[i] && x_coor[i] <= 10 + (qreal)(j+1) * t_time * t_time / time_base)
            {
                if (j % 2 == 0)
                {
                    x = x_coor[i];
                    y = middle_1 - 2 * (qreal)a_tension * a_tension / tension_div;
//                            - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (a_tension / tension_div);
                    if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                    {
                        p.setX(x);
                        p.setY(y);
                        point_chan1_rect.append(p);
                    }
                    else
                    {
                        p.setX(x);
                        p.setY(middle_1);
                        point_chan1_rect.append(p);
                    }
                }
                else
                {
                    x = x_coor[i];
                    y = middle_1;
//                            - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (a_tension / tension_div);
                    if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                    {
                        p.setX(x);
                        p.setY(y);
                        point_chan1_rect.append(p);
                    }
                    else
                    {
                        p.setX(x);
                        p.setY(middle_1);
                        point_chan1_rect.append(p);
                    }
                }
            }
            j++;
        }
    }

    if (trigger_rising->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan1_rect.count(); i++)
        {
            p1 = point_chan1_rect[i];
            point_for_trigger.append(p1);
        }
        point_chan1_rect.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() < point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan1_rect.append(p1);
            }
        }
    }
    else if (trigger_falling->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan1_rect.count(); i++)
        {
            p1 = point_chan1_rect[i];
            point_for_trigger.append(p1);
        }
        point_chan1_rect.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() > point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan1_rect.append(p1);
            }
        }
    }
    else if (trigger_off->isChecked())
    {

    }
}

// Set channel 1 sawt x,y

void myWindow::set_chan1_sawt()
{
    QPointF p;
    qreal x, y, m;
    int j;

    for (int i=0; i < x_coor.count(); i++)
    {
        j = 0;
        while (j < x_coor.count() / samp_num)
        {
            if (10 + (qreal)j * t_time * t_time / time_base <= x_coor[i] && x_coor[i] <= 10 + (qreal)(j+1) * t_time * t_time / time_base)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base) / ((qreal)t_time * t_time / time_base);
                x = x_coor[i];
                y = middle_1 - 2 * (qreal)a_tension * a_tension / tension_div * m;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (a_tension / tension_div);
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan1_sawt.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan1_sawt.append(p);
                }
            }
            j++;
        }
    }

    if (trigger_rising->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan1_sawt.count(); i++)
        {
            p1 = point_chan1_sawt[i];
            point_for_trigger.append(p1);
        }
        point_chan1_sawt.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() < point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan1_sawt.append(p1);
            }
        }
    }
    else if (trigger_falling->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan1_sawt.count(); i++)
        {
            p1 = point_chan1_sawt[i];
            point_for_trigger.append(p1);
        }
        point_chan1_sawt.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() > point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan1_sawt.append(p1);
            }
        }
    }
    else if (trigger_off->isChecked())
    {

    }
}

// Set channel 2 trig x,y

void myWindow::set_chan2_trig()
{
    QPointF p;
    qreal x, y, m;
    int j = 0;

    for (int i=0; i < x_coor.count(); i++)
    {
        j = 0;
        while (j < x_coor.count() / samp_num)
        {
            if (10 + (qreal)j * t_time * t_time / time_base <= x_coor[i] && x_coor[i] <= 10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base / 4)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base) / ((qreal)t_time * t_time / time_base / 4);
                x = x_coor[i];
                y = middle_1 - a_tension * (qreal)a_tension / tension_div
                        - a_tension * (qreal)a_tension / tension_div * m
                        - 2 * a_tension * (qreal)a_tension / tension_div;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (qreal)a_tension / tension_div;
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan2_trig.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan2_trig.append(p);
                }
            }
            else if (10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base / 4 <= x_coor[i] && x_coor[i] <= 10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base / 2)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base - (qreal)t_time * t_time / time_base / 4) / ((qreal)t_time * t_time / time_base / 4);
                x = x_coor[i];
                y = middle_1 - 2 * a_tension * (a_tension / tension_div)
                        + a_tension * (qreal)a_tension / tension_div * m
                        - 2 * a_tension * (qreal)a_tension / tension_div;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (qreal)a_tension / tension_div;
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan2_trig.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan2_trig.append(p);
                }
            }
            else if (10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base / 2 <= x_coor[i] && x_coor[i] <= 10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base * 3 / 4)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base - (qreal)t_time * t_time / time_base / 2) / ((qreal)t_time * t_time / time_base / 4);
                x = x_coor[i];
                y = middle_1 - a_tension * (a_tension / tension_div)
                        + a_tension * (qreal)a_tension / tension_div * m
                        - 2 * a_tension * (qreal)a_tension / tension_div;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (qreal)a_tension / tension_div;
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan2_trig.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan2_trig.append(p);
                }
            }
            else if (10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base * 3 / 4 <= x_coor[i] && x_coor[i] <= 10 + (qreal)j * t_time * t_time / time_base + (qreal)t_time * t_time / time_base)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base - (qreal)t_time * t_time / time_base * 3 / 4) / ((qreal)t_time * t_time / time_base / 4);
                x = x_coor[i];
                y = middle_1
                        - a_tension * (qreal)a_tension / tension_div * m
                        - 2 * a_tension * (qreal)a_tension / tension_div;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (qreal)a_tension / tension_div;
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan2_trig.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan2_trig.append(p);
                }
            }
            j++;
        }
    }

    if (trigger_rising->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan2_trig.count(); i++)
        {
            p1 = point_chan2_trig[i];
            point_for_trigger.append(p1);
        }
        point_chan2_trig.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() < point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan2_trig.append(p1);
            }
        }
    }
    else if (trigger_falling->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan2_trig.count(); i++)
        {
            p1 = point_chan2_trig[i];
            point_for_trigger.append(p1);
        }
        point_chan2_trig.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() > point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan2_trig.append(p1);
            }
        }
    }
    else if (trigger_off->isChecked())
    {

    }
}

// Set channel 2 sina x,y

void myWindow::set_chan2_sina()
{
    QPointF p;
    qreal x, y, a;
    qreal TWOPI = 6.28318;
    int j;

    for (int i=0; i < x_coor.count(); i++)
    {
        j = 0;
        while (j < x_coor.count() / samp_num)
        {
            if (10 + (qreal)j * t_time * t_time / time_base <= x_coor[i] && x_coor[i] <= 10 + (qreal)(j+1) * t_time * t_time / time_base)
            {
                x = x_coor[i];
                a = TWOPI * (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base) / (t_time * t_time / time_base);
                y = middle_1 - (qreal)a_tension * a_tension / tension_div
                        - (qreal)a_tension * a_tension / tension_div * sin(a)
                        - 2 * a_tension * (qreal)a_tension / tension_div;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (qreal)a_tension / tension_div;
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan2_sina.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan2_sina.append(p);
                }
            }
            j++;
        }
    }

    if (trigger_rising->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan2_sina.count(); i++)
        {
            p1 = point_chan2_sina[i];
            point_for_trigger.append(p1);
        }
        point_chan2_sina.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() < point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan2_sina.append(p1);
            }
        }
    }
    else if (trigger_falling->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan2_sina.count(); i++)
        {
            p1 = point_chan2_sina[i];
            point_for_trigger.append(p1);
        }
        point_chan2_sina.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() > point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan2_sina.append(p1);
            }
        }
    }
    else if (trigger_off->isChecked())
    {

    }
}

// Set channel 2 rect x,y

void myWindow::set_chan2_rect()
{
    QPointF p;
    qreal x, y;
    int j;

    for (int i=0; i < x_coor.count(); i++)
    {
        j = 0;
        while (j < x_coor.count() / samp_num)
        {
            if (10 + (qreal)j * t_time * t_time / time_base <= x_coor[i] && x_coor[i] <= 10 + (qreal)(j+1) * t_time * t_time / time_base)
            {
                if (j % 2 == 0)
                {
                    x = x_coor[i];
                    y = middle_1 - 2 * (qreal)a_tension * a_tension / tension_div
                            - 2 * a_tension * (qreal)a_tension / tension_div;
    //                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (qreal)a_tension / tension_div;
                    if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                    {
                        p.setX(x);
                        p.setY(y);
                        point_chan2_rect.append(p);
                    }
                    else
                    {
                        p.setX(x);
                        p.setY(middle_1);
                        point_chan2_rect.append(p);
                    }
                }
                else
                {
                    x = x_coor[i];
                    y = middle_1
                            - 2 * a_tension * (qreal)a_tension / tension_div;
    //                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (qreal)a_tension / tension_div;
                    if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                    {
                        p.setX(x);
                        p.setY(y);
                        point_chan2_rect.append(p);
                    }
                    else
                    {
                        p.setX(x);
                        p.setY(middle_1);
                        point_chan2_rect.append(p);
                    }
                }
            }
            j++;
        }
    }

    if (trigger_rising->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan2_rect.count(); i++)
        {
            p1 = point_chan2_rect[i];
            point_for_trigger.append(p1);
        }
        point_chan2_rect.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() < point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan2_rect.append(p1);
            }
        }
    }
    else if (trigger_falling->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan2_rect.count(); i++)
        {
            p1 = point_chan2_rect[i];
            point_for_trigger.append(p1);
        }
        point_chan2_rect.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() > point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan2_rect.append(p1);
            }
        }
    }
    else if (trigger_off->isChecked())
    {

    }
}

// Set channel 2 sawt x,y

void myWindow::set_chan2_sawt()
{
    QPointF p;
    qreal x, y, m;
    int j;

    for (int i=0; i < x_coor.count(); i++)
    {
        j = 0;
        while (j < x_coor.count() / samp_num)
        {
            if (10 + (qreal)j * t_time * t_time / time_base <= x_coor[i] && x_coor[i] <= 10 + (qreal)(j+1) * t_time * t_time / time_base)
            {
                m = (x_coor[i] - 10 - (qreal)j * t_time * t_time / time_base) / ((qreal)t_time * t_time / time_base);
                x = x_coor[i];
                y = middle_1 - 2 * (qreal)a_tension * a_tension / tension_div * m
                        - 2 * a_tension * (qreal)a_tension / tension_div;
//                        - (qreal)(qrand() % 3) / 16 / 0.5 * a_tension * (qreal)a_tension / tension_div;
                if (y >= middle_1 - limit_volt / 0.5 * a_tension * (qreal)a_tension / tension_div)
                {
                    p.setX(x);
                    p.setY(y);
                    point_chan2_sawt.append(p);
                }
                else
                {
                    p.setX(x);
                    p.setY(middle_1);
                    point_chan2_sawt.append(p);
                }
            }
            j++;
        }
    }

    if (trigger_rising->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan2_sawt.count(); i++)
        {
            p1 = point_chan2_sawt[i];
            point_for_trigger.append(p1);
        }
        point_chan2_sawt.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() < point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan2_sawt.append(p1);
            }
        }
    }
    else if (trigger_falling->isChecked())
    {
        QPointF p1;
        int trigger_locate = 0;

        point_for_trigger.clear();
        for (int i=0; i<point_chan2_sawt.count(); i++)
        {
            p1 = point_chan2_sawt[i];
            point_for_trigger.append(p1);
        }
        point_chan2_sawt.clear();
        for (int i=0; i<point_for_trigger.count(); i++)
        {
            if (point_for_trigger[i].y() <= middle_1 - trigger_volt / 0.5 * a_tension * a_tension / tension_div
                    && point_for_trigger[i+1].y() > point_for_trigger[i].y())
            {
                trigger_locate = i;   // find triggering point at location i
                break;
            }
            trigger_locate = point_for_trigger.count();  // not find triggering point
        }
        if (trigger_locate != point_for_trigger.count())
        {
            for (int i=trigger_locate; i<point_for_trigger.count(); i++)
            {
                p1 = point_for_trigger[i];
                point_chan2_sawt.append(p1);
            }
        }
    }
    else if (trigger_off->isChecked())
    {

    }
}

/* Execute the three .so files */

//void *handle;
//void (*myfun)(void);
//char *error;

//handle = dlopen ("/lib/limit_level.so", RTLD_LAZY);
//if (!handle) {
//   fprintf (stderr, "%s\n", dlerror());
// }

//dlerror();
// *(void **) (&myfun) = dlsym(handle, "limit");

//dlerror();

//(*myfun)();
//dlclose(handle);


//void *handle1;
//void (*myfun1)(void);
//char *error1;

//handle1 = dlopen ("/lib/mean.so", RTLD_LAZY);
//if (!handle1) {
//   fprintf (stderr, "%s\n", dlerror());
// }

//dlerror();
// *(void **) (&myfun1) = dlsym(handle, "mean");

//dlerror();

//(*myfun1)();
//dlclose(handle1);


//void *handle2;
//void (*myfun2)(void);
//char *error2;

//handle2 = dlopen ("/lib/sum.so", RTLD_LAZY);
//if (!handle2) {
//   fprintf (stderr, "%s\n", dlerror());
// }

//dlerror();
// *(void **) (&myfun2) = dlsym(handle, "sum");

//dlerror();

//(*myfun2)();
//dlclose(handle2);


// Control Time Base

void myWindow::slower_timebase()
{
    time_base *= 2;

    generate_x();

    point_chan1_trig.clear();
    set_chan1_trig();

    point_chan1_sina.clear();
    set_chan1_sina();

    point_chan1_rect.clear();
    set_chan1_rect();

    point_chan1_sawt.clear();
    set_chan1_sawt();

    point_chan2_trig.clear();
    set_chan2_trig();

    point_chan2_sina.clear();
    set_chan2_sina();

    point_chan2_rect.clear();
    set_chan2_rect();

    point_chan2_sawt.clear();
    set_chan2_sawt();

    update();
}

void myWindow::faster_timebase()
{
    time_base /= 2;

    generate_x();

    point_chan1_trig.clear();
    set_chan1_trig();

    point_chan1_sina.clear();
    set_chan1_sina();

    point_chan1_rect.clear();
    set_chan1_rect();

    point_chan1_sawt.clear();
    set_chan1_sawt();

    point_chan2_trig.clear();
    set_chan2_trig();

    point_chan2_sina.clear();
    set_chan2_sina();

    point_chan2_rect.clear();
    set_chan2_rect();

    point_chan2_sawt.clear();
    set_chan2_sawt();

    update();
}

// Control Tension Base

void myWindow::raise_tension()
{
    tension_div *= 2;

    point_chan1_trig.clear();
    set_chan1_trig();

    point_chan1_sina.clear();
    set_chan1_sina();

    point_chan1_rect.clear();
    set_chan1_rect();

    point_chan1_sawt.clear();
    set_chan1_sawt();

    point_chan2_trig.clear();
    set_chan2_trig();

    point_chan2_sina.clear();
    set_chan2_sina();

    point_chan2_rect.clear();
    set_chan2_rect();

    point_chan2_sawt.clear();
    set_chan2_sawt();

    update();
}

void myWindow::lower_tension()
{
    tension_div /= 2;

    point_chan1_trig.clear();
    set_chan1_trig();

    point_chan1_sina.clear();
    set_chan1_sina();

    point_chan1_rect.clear();
    set_chan1_rect();

    point_chan1_sawt.clear();
    set_chan1_sawt();

    point_chan2_trig.clear();
    set_chan2_trig();

    point_chan2_sina.clear();
    set_chan2_sina();

    point_chan2_rect.clear();
    set_chan2_rect();

    point_chan2_sawt.clear();
    set_chan2_sawt();

    update();
}

// Triggering mode

void myWindow::raise_trigger()
{
    trigger_volt += 0.1;
}

void myWindow::lower_trigger()
{
    trigger_volt -= 0.1;
}

// Refresh the screen

void myWindow::refresh()
{
    action_chan1_trig->setChecked(false);
    action_chan1_sina->setChecked(false);
    action_chan1_rect->setChecked(false);
    action_chan1_sawt->setChecked(false);
    action_chan2_trig->setChecked(false);
    action_chan2_sina->setChecked(false);
    action_chan2_rect->setChecked(false);
    action_chan2_sawt->setChecked(false);

    time_base = 30;
    tension_div = 10;

    trigger_volt = INITIAL_TRIGGER_VOLT;

    generate_x();

    update();
}

/* Open and show the content of one file (chanN.pcm or cle.cfg) */

void myWindow::openFile()
{
    QString openFile = QFileDialog::getOpenFileName(this, tr("Open file"), savePath);
//    QString command = QString("%1%2").arg("cat ").arg(openFile);
//    QByteArray ba = command.toLatin1();
//    const char *str = ba.data();
//    system(str);
    QFile fileOpened(openFile);
    QString fileContent("");
    if (fileOpened.open(fileOpened.ReadOnly))
    {
        QTextStream tsFile(&fileOpened);
        while (!tsFile.atEnd())
        {
            fileContent.append(tsFile.readLine());
            fileContent.append("\n");
        }
    }
    fileOpened.close();
    megBox = new QMessageBox;
    megBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    megBox->setDetailedText(fileContent);
    megBox->show();
}

/* Save the fours files chanN.pcm and the configuration file cle.cfg */

void myWindow::saveFiles()
{
    /* Save the two files chan1.pcm and chan2.pcm */

    // chan1.pcm  (signal triangulaire)
    QString nameChan1("chan1.pcm");
    QFile fChan1(savePath + nameChan1);
    fChan1.open(QFile::WriteOnly | QFile::Truncate);
    QDataStream dsChan1(&fChan1);

    if (action_chan1_trig->isChecked())
    {
        for (int i1=0; i1<point_chan1_trig.count(); i1++)
        {
            dsChan1 << (qint16)((qAbs(middle_1 - point_chan1_trig[i1].y()) * 0.5 * (qreal)tension_div / a_tension / a_tension) * 1024 / 3.3 - 1);
        }
    }
    else if (action_chan1_sina->isChecked())
    {
        for (int i1=0; i1<point_chan1_sina.count(); i1++)
        {
            dsChan1 << (qint16)((qAbs(middle_1 - point_chan1_sina[i1].y()) * 0.5 * (qreal)tension_div / a_tension / a_tension) * 1024 / 3.3 - 1);
        }
    }
    else if (action_chan1_rect->isChecked())
    {
        for (int i1=0; i1<point_chan1_rect.count(); i1++)
        {
            dsChan1 << (qint16)((qAbs(middle_1 - point_chan1_rect[i1].y()) * 0.5 * (qreal)tension_div / a_tension / a_tension) * 1024 / 3.3 - 1);
        }
    }
    else if (action_chan1_sawt->isChecked())
    {
        for (int i1=0; i1<point_chan1_sawt.count(); i1++)
        {
            dsChan1 << (qint16)((qAbs(middle_1 - point_chan1_sawt[i1].y()) * 0.5 * (qreal)tension_div / a_tension / a_tension) * 1024 / 3.3 - 1);
        }
    }
    fChan1.close();

    // chan2.pcm  (signal sinusoïdale)
    QString nameChan2("chan2.pcm");
    QFile fChan2(savePath + nameChan2);
    fChan2.open(QFile::WriteOnly | QFile::Truncate);
    QDataStream dsChan2(&fChan2);

    if (action_chan2_trig->isChecked())
    {
        for (int i1=0; i1<point_chan2_trig.count(); i1++)
        {
            dsChan2 << (qint16)((qAbs(middle_1 - point_chan2_trig[i1].y()) * 0.5 * (qreal)tension_div / a_tension / a_tension) * 1024 / 3.3 - 1);
        }
    }
    else if (action_chan2_sina->isChecked())
    {
        for (int i1=0; i1<point_chan2_sina.count(); i1++)
        {
            dsChan2 << (qint16)((qAbs(middle_1 - point_chan2_sina[i1].y()) * 0.5 * (qreal)tension_div / a_tension / a_tension) * 1024 / 3.3 - 1);
        }
    }
    else if (action_chan2_rect->isChecked())
    {
        for (int i1=0; i1<point_chan2_rect.count(); i1++)
        {
            dsChan2 << (qint16)((qAbs(middle_1 - point_chan2_rect[i1].y()) * 0.5 * (qreal)tension_div / a_tension / a_tension) * 1024 / 3.3 - 1);
        }
    }
    else if (action_chan2_sawt->isChecked())
    {
        for (int i1=0; i1<point_chan2_sawt.count(); i1++)
        {
            dsChan2 << (qint16)((qAbs(middle_1 - point_chan2_sawt[i1].y()) * 0.5 * (qreal)tension_div / a_tension / a_tension) * 1024 / 3.3 - 1);
        }
    }
    fChan2.close();


    /* cle.cfg */
//    QString nameCfg = QFileDialog::getSaveFileName(this, tr("Save file"),
//                    savePath + "cle.cfg", tr("Text files (*.pcm *.cfg)"));
    QString nameCfg("cle.cfg");
    QFile fCfg(savePath + nameCfg);
    fCfg.open(QFile::WriteOnly | QFile::Truncate);
    QTextStream tsCfg(&fCfg);
    QDate qDate;
    QTime qTime;
    tsCfg <<"# Version du format de fichier"<<endl<<"version=1.0"<<endl
    <<"# date au format ISO 8601"<<endl<<"date=\""<<qDate.currentDate().toString(Qt::ISODate)
    <<"T"<<qTime.currentTime().toString(Qt::TextDate)<<"Z\""<<endl<<
    endl<<"sample {"<<endl<<"\t# Nombre d'echantillons."
    <<endl<<"\tcount="<<x_coor.count()
    <<endl<<"\t# duree de l'ensemble des echantillons. Ici "<< 0.03 * time_base / t_time <<"ms pour les "<<x_coor.count()
    <<endl<<"\t# echantillons. A partir de cette valeur et du nombre"
    <<endl<<"\t# d'echantillons on en deduit la periode d'echantillonnage."
    <<endl<<"\tduration="<< 0.03 * time_base / t_time
    <<endl<<"}"<<endl<<endl<<"# Les voies sont sauvegardees dans l'ordre 1 vers 4 (ou plus)"
    <<endl<<"# Voie 1"
    <<endl<<"channel {"
    <<endl<<"\tname=\"Signal triangulaire\""
    <<endl<<"\t# type de couplage AC ou DC"
    <<endl<<"\tcoupling=DC"
    <<endl<<"\tfile {"
    <<endl<<"\t\t# nom du fichier binaire associe a cette voie"
    <<endl<<"\t\tfilename=\"chan1.pcm\""
    <<endl<<endl<<"\t\t# format des donnees dans le fichier :"
    <<endl<<"\t\t#  16_LE : 16 bits little endian"
    <<endl<<"\t\t#  16_BE : 16 bits big endian"
    <<endl<<"\t\t#  32_LE : 32 bits little endian"
    <<endl<<"\t\t#  32_BE : 32 bits big endian"
    <<endl<<"\t\tformat=16_LE"
    <<endl<<endl<<"\t\t# valeur min/max en Volt d'un echantillon"
    <<endl<<"\t\tmin_voltage="<<"0"
    <<endl<<"\t\tmax_voltage="<<limit_volt
    <<endl<<"\t}"<<endl<<"}"<<endl<<endl
    <<"# Voie 2"
    <<endl<<"channel {"
    <<endl<<"\tname=\"Signal sinusoidale\""
    <<endl<<"\tcoupling=DC"
    <<endl<<"\tfile {"
    <<endl<<"\t\tfilename=\"chan2.pcm\""
    <<endl<<"\t\tformat=16_LE"
    <<endl<<"\t\tmin_voltage="<<"0"
    <<endl<<"\t\tmax_voltage="<<limit_volt
    <<endl<<"\t}"<<endl<<"}";
}

/* Three plugins */

// Computes the sum of 2 signals

void myWindow::draw_sum(QPainter *painter)
{
    painter->setPen(Qt::red);
    display_sum(painter);
}

void myWindow::display_sum(QPainter* painter)
{
    point_sum.clear();
    set_sum();
    painter->drawPoints(point_sum);
}

void myWindow::set_sum()
{
    QPointF p;
    qreal x, y;

    if (action_chan1_trig->isChecked() && action_chan2_trig->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_trig[i].y() + point_chan2_trig[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_trig->isChecked() && action_chan2_sina->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_trig[i].y() + point_chan2_sina[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_trig->isChecked() && action_chan2_rect->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_trig[i].y() + point_chan2_rect[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_trig->isChecked() && action_chan2_sawt->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_trig[i].y() + point_chan2_sawt[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_sina->isChecked() && action_chan2_trig->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_sina[i].y() + point_chan2_trig[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_sina->isChecked() && action_chan2_sina->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_sina[i].y() + point_chan2_sina[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_sina->isChecked() && action_chan2_rect->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_sina[i].y() + point_chan2_rect[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_sina->isChecked() && action_chan2_sawt->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_sina[i].y() + point_chan2_sawt[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_rect->isChecked() && action_chan2_trig->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_rect[i].y() + point_chan2_trig[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_rect->isChecked() && action_chan2_sina->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_rect[i].y() + point_chan2_sina[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_rect->isChecked() && action_chan2_rect->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_rect[i].y() + point_chan2_rect[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_rect->isChecked() && action_chan2_sawt->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_rect[i].y() + point_chan2_sawt[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_sawt->isChecked() && action_chan2_trig->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_sawt[i].y() + point_chan2_trig[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_sawt->isChecked() && action_chan2_sina->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_sawt[i].y() + point_chan2_sina[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_sawt->isChecked() && action_chan2_rect->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_sawt[i].y() + point_chan2_rect[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
    else if (action_chan1_sawt->isChecked() && action_chan2_sawt->isChecked())
    {
        for (int i=0; i<x_coor.count(); i++)
        {
            x = x_coor[i];
            y = point_chan1_sawt[i].y() + point_chan2_sawt[i].y() - middle_1;
            p.setX(x);
            p.setY(y);
            point_sum.append(p);
        }
    }
}

// Draw the Time Base, Trigger voltage,

void myWindow::draw_infor(QPainter* painter)
{
    QPen pen(Qt::blue);
    painter->setPen(pen);
    QFont font("Arial", 26, QFont::DemiBold, false);
    painter->setFont(font);

    /* Draw Sampling Rate */
    painter->drawText(27, 202, QString::number(INITIAL_SAMPLE_RATE) + " S/s");

    /* Draw Time Base */
    painter->drawText(196, 152, QString::number(3 * time_base / t_time, 'g', 2) + " ms/div");

    /* Draw Tension Base */
    painter->drawText(196, 174, QString::number(0.5 * tension_div / a_tension, 'g', 2) + " V/div");

    /* Draw Trigger Volt */
    painter->drawText(196, 198, QString::number(trigger_volt, 'g', 2) + " V");
}

// Compute the mean of all the signals

void myWindow::mean(QPainter* painter)
{
    QPen pen(Qt::blue);
    painter->setPen(pen);
    QFont font("Arial", 26, QFont::DemiBold, false);
    painter->setFont(font);
    /* Draw the prompts of Mean of the two channels */
    painter->drawText(27, 152, tr("Mean1:"));
    painter->drawText(27, 174, tr("Mean2:"));

    qreal sum;

    // Calcul the mean for channel 1
    if (action_chan1_trig->isChecked())
    {
        sum = 0;
        for (int i=0; i<x_coor.count(); i++)
        {
            sum += point_chan1_trig[i].y();
        }
        mean_chan1 = sum / x_coor.count();
    }
    else if (action_chan1_sina->isChecked())
    {
        sum = 0;
        for (int i=0; i<x_coor.count(); i++)
        {
            sum += point_chan1_sina[i].y();
        }
        mean_chan1 = sum / x_coor.count();
    }
    else if (action_chan1_rect->isChecked())
    {
        sum = 0;
        for (int i=0; i<x_coor.count(); i++)
        {
            sum += point_chan1_rect[i].y();
        }
        mean_chan1 = sum / x_coor.count();
    }
    else if (action_chan1_sawt->isChecked())
    {
        sum = 0;
        for (int i=0; i<x_coor.count(); i++)
        {
            sum += point_chan1_sawt[i].y();
        }
        mean_chan1 = sum / x_coor.count();
    }
    else
    {
        mean_chan1 = EMPTY;
    }

    // Calcul the mean for channel 2
    if (action_chan2_trig->isChecked())
    {
        sum = 0;
        for (int i=0; i<x_coor.count(); i++)
        {
            sum += point_chan2_trig[i].y();
        }
        mean_chan2 = sum / x_coor.count();
    }
    else if (action_chan2_sina->isChecked())
    {
        sum = 0;
        for (int i=0; i<x_coor.count(); i++)
        {
            sum += point_chan2_sina[i].y();
        }
        mean_chan2 = sum / x_coor.count();
    }
    else if (action_chan2_rect->isChecked())
    {
        sum = 0;
        for (int i=0; i<x_coor.count(); i++)
        {
            sum += point_chan2_rect[i].y();
        }
        mean_chan2 = sum / x_coor.count();
    }
    else if (action_chan2_sawt->isChecked())
    {
        sum = 0;
        for (int i=0; i<x_coor.count(); i++)
        {
            sum += point_chan2_sawt[i].y();
        }
        mean_chan2 = sum / x_coor.count();
    }
    else
    {
        mean_chan2 = EMPTY;
    }

    if (mean_chan1 != EMPTY)
    {
        mean_chan1 = (middle_1 - mean_chan1) / (a_tension * a_tension / tension_div) * 0.5;
        painter->drawText(73, 152, QString::number(mean_chan1, 'g', 2));
    }

    if (mean_chan2 != EMPTY)
    {
        mean_chan2 = (middle_1 - mean_chan2) / (a_tension * a_tension / tension_div) * 0.5;
        painter->drawText(73, 174, QString::number(mean_chan2, 'g', 2));
    }
}

/* Destructor */

myWindow::~myWindow()
{
    delete ui;
}

//class SleeperThread : public QThread
//{
//public:
//    static void msleep(unsigned long msecs)
//    {
//        QThread::msleep(msecs);
//    }
//};
