#ifndef SIGNAL_H
#define SIGNAL_H

class Signal
{
public:

private:

};

#endif // SIGNAL_H
