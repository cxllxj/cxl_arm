#ifndef CHANNEL_H
#define CHANNEL_H

#include "signal.h"

class Channel
{
public:

private:

};

#endif // CHANNEL_H
