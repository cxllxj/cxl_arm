#!/bin/bash

# If there occurs an error, exit the whole script
set -e

base=$PWD

echo "################## GETTING QEMU ##################"
cd $base/direct_test
git clone git://repo.or.cz/qemu/mini2440.git qemu
mkdir local
cd qemu
./configure --target-list=arm-softmmu --prefix=$base/direct_test/local
make
make install

export PATH=$base/direct_test/bin:$PATH

echo "################## STARTING QEMU ##################"
cd ../..
qemu-system-arm -M mini2440 -serial stdio -mtdblock nand.bin -usbdevice mouse
