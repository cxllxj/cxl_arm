Run the emulation with:

 qemu-system-ppc -M mpc8544ds -kernel output/images/vmlinux -serial stdio

The login prompt will appear in the terminal that started Qemu.

